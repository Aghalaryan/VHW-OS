﻿using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace HW
{
    class HW
    {

        static void Main(string[] args)
        {
            HDD.Init();
            Clock.Init();

            Clock.ClockEvent += Func3;
            HDD.ReadEvent += Func1;
            HDD.WriteEvent += Func2;


            byte[] arr = new byte[20];
            for (int i = 0; i < 20; ++i)
                arr[i] = (byte)(i + 97);

            HDD.Write(0, arr);
            Console.WriteLine("First write");

            HDD.Write(20, arr);
            Console.WriteLine("Second write");

            byte[] readto = new byte[200];
            rd = false;

            HDD.Read(readto, 0, 200);

            while (!rd) ;

            Console.WriteLine(Encoding.Default.GetString(readto));
            HDD.Close();

            Console.ReadLine();
        }

        public static bool rd;
        public static void Func1(bool st)
        {
            Console.WriteLine("readEvent " + st);
            rd = st;
        }

        public static void Func2(bool st)
        {
            Console.WriteLine("writeEvent " + st);
        }

        public static void Func3()
        {
            Console.WriteLine("Ring!!!");
        }

    }


    public static class HDD
    {
        private const string _filePath = "HDD.txt";
        private static FileStream _fileStream;

        public delegate void WriteEventHendler(bool state);
        public static event WriteEventHendler WriteEvent;

        public delegate void ReadEventHendler(bool state);
        public static event ReadEventHendler ReadEvent;


        public static void Init()
        {
            try
            {
                _fileStream = Open(_filePath);
            }
            catch (Exception ex)
            {
                throw new Exception(@"An error occurred during file open process: {ex.Message}");
            }

        }

        public static void Close()
        {
            _fileStream.Close();

        }

        private static FileStream Open(string path)
        {
            return File.Open(path, FileMode.Open, FileAccess.ReadWrite);
        }

        public static async Task Read(byte[] buffer, long offset, long size)
        {

            bool state = true;
            _fileStream.Seek(offset, SeekOrigin.Begin);
            try
            {
                await _fileStream.ReadAsync(buffer, 0, Convert.ToInt32(size));
            }
            catch (Exception ex)
            {
                state = false;
            }


            if (ReadEvent != null)
                ReadEvent(state);


        }


        public static async Task Write(long address, byte[] buff)
        {

            bool state = true;
            _fileStream.Seek(address, SeekOrigin.Begin);
            try
            {
                await _fileStream.WriteAsync(buff, 0, buff.Length);
            }
            catch (Exception ex)
            {
                state = false;
            }

            if (WriteEvent != null)
                WriteEvent(state);


        }


    }
    public static class Clock
    {
        private static System.Timers.Timer clock;
        private static int count;

        public delegate void ClockEventHendler();
        public static event ClockEventHendler ClockEvent;

        public static void Init()
        {
            count = 0;
            clock = new System.Timers.Timer(1000);

            clock.Elapsed += OnTimedEvent;

            clock.AutoReset = true;
            clock.Enabled = true;

        }
        private static void OnTimedEvent(Object source, System.Timers.ElapsedEventArgs e)
        {
            if (ClockEvent != null)
                ClockEvent();
        }
    }

    public static class IOstrem
    {
        public static void print(string s)
        {
            Console.WriteLine(s);

        }

        public static void scan(string s)
        {
            s = Console.ReadLine();
        }
    }



}
